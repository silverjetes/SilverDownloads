Windows Classic Sounds for XP
=============================
v.1.0 (20 October 2010)

Ten original "classic" Windows sound schemes adapted for Windows XP:
. Windows 3.1 (1992)
. Windows 95 (1995)
. Windows NT 4 (1996)
. Windows 98 (1998)
. Windows 2000 (2000)
. Windows Me (2000)
. Musica, Robotz, Utopia and Jungle schemes from Windows Me.

. 122 WAV files

To install.
1 Copy the "Windows Classic" folder and contents as a subfoler of \windows\media
   i.e. \windows\media\Windows Classic\
2. Double-click the winClassicSounds.reg file to merge with the Windows Registry
   When asked "Are you sure you want to add the information..." choose "Yes"
3. Open the Sounds and Audio Devices control applet in Contol Panel
   Start\Control Panel\Sounds and Audio Devices
4. Click on the "Sounds" tab
5. Choose one of the 10 Windows Classic schemes in the "Sound scheme" drop-down list
   Choose to save your existing sound scheme if required
6. Click OK

To uninstall.
1. Open the Sounds and Audio Devices control applet in Contol Panel
   Start\Control Panel\Sounds and Audio Devices
2. Select the "Sounds" tab
3. Choose the relevant Windows Classic sound scheme in the "Sound scheme" drop-down list
4. Select Delete to delete the sound scheme (note, this only deletes the scheme list not the files).
5. To delete the sound files if desired, delete the \windows\media\Windows Classic\ folder.

Note:
All the original sound files found in the Windows versions are included.
The sound schemes follow the original schemes as laid out by Microsoft; you will find that
Microsoft chose not to use some of the sound files although they were present.
Feel free to update the schemes according to your preferences.


 